# NEXORA — Business Services Platform

Dark 3D digital agency starter for:
- Web development
- 3D design & experiences
- Digital marketing

Includes a Next.js App Router frontend, animated 3D hero, Supabase email/password auth, customer service request workflow, and role-protected admin pages.

## Requirements
- Node.js LTS
- npm
- Supabase project
- Git (recommended)

## 1. Install and run locally

```bash
npm install
cp .env.example .env.local
```

On Windows PowerShell, if `cp` is unavailable:
```powershell
Copy-Item .env.example .env.local
```

Fill `.env.local` with the Supabase Project URL and publishable key. Then run:

```bash
npm run dev
```

Open http://localhost:3000.

## 2. Supabase setup
1. Create a project in https://supabase.com/dashboard.
2. Open SQL Editor.
3. Run `supabase/migrations/001_initial_schema.sql`.
4. In Authentication URL configuration, add `http://localhost:3000` to Site URL / Redirect URLs.
5. Configure production URLs after deployment.
6. Configure email delivery for production rather than relying on development defaults.

The migration creates tables, RLS policies, a profile/role provisioning trigger, and the three initial services.

## 3. Create an admin
1. Register a user through `/signup` and verify the email if enabled.
2. In Supabase Dashboard > Authentication > Users, copy that user's UUID.
3. In SQL Editor, run (replace the UUID):
```sql
insert into public.user_roles (user_id, role)
values ('YOUR_AUTH_USER_UUID', 'admin')
on conflict (user_id) do update set role = 'admin';
```
Never expose a service-role key or an admin-role mutation to the browser.

## 4. Routes
- `/` — landing page
- `/signup` — registration
- `/login` — login
- `/dashboard` — customer portal
- `/dashboard/new-request` — new service request
- `/admin` — admin overview
- `/admin/users` — users
- `/admin/services` — service catalogue
- `/admin/requests` — request management

## 5. Production deployment
1. Push code to a private GitHub repository.
2. Import repository in Vercel.
3. Add the same environment variables from `.env.local` to Vercel Production (never commit `.env.local`).
4. Deploy and connect your custom domain.
5. Update Supabase Site URL and Redirect URLs to the real HTTPS domain.
6. Test signup, email verification, password reset, user isolation, admin access, request status changes, backups and mobile layouts.

## Security and completeness notes
- Review the SQL migration and policies in a non-production project before launch.
- Add password reset UI, rate limiting / bot protection, error monitoring, audit logging, privacy policy, terms, support messaging and backup/restore drills before commercial launch.
- Keep admin roles assigned only by trusted operators.
- Validate all inputs and test every authorization rule with both user and admin accounts.
- Do not add secret or service-role keys to `NEXT_PUBLIC_*` variables.
- The starter provides a foundation, not a claim of completed production security audit.
