import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Users, BriefcaseBusiness, ClipboardList, ArrowUpRight } from "lucide-react";

export default async function AdminOverview() {
  const supabase = await createClient();
  const [users, services, requests, pending] = await Promise.all([
    supabase.from("profiles").select("*",{count:"exact",head:true}),
    supabase.from("services").select("*",{count:"exact",head:true}),
    supabase.from("service_requests").select("*",{count:"exact",head:true}),
    supabase.from("service_requests").select("*",{count:"exact",head:true}).eq("status","pending"),
  ]);
  const stats = [
    {label:"Customer profiles",value:users.count??0,Icon:Users},
    {label:"Services",value:services.count??0,Icon:BriefcaseBusiness},
    {label:"Total requests",value:requests.count??0,Icon:ClipboardList},
    {label:"Pending requests",value:pending.count??0,Icon:ClipboardList},
  ];
  return <div>
    <div className="eyebrow">Control center</div><h1 style={{fontSize:36,letterSpacing:"-.04em",margin:"10px 0"}}>Admin overview</h1><p className="muted">Manage NEXORA operations from one workspace.</p>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(155px,1fr))",gap:12,marginTop:24}}>
      {stats.map(s=><div key={s.label} className="card" style={{padding:18}}><s.Icon size={20} color="#b6a7ff"/><div className="muted" style={{fontSize:12,marginTop:14}}>{s.label}</div><div style={{fontSize:32,fontWeight:800,marginTop:5}}>{s.value}</div></div>)}
    </div>
    <div className="card" style={{padding:22,marginTop:18}}><h2 style={{fontSize:20,marginTop:0}}>Quick actions</h2><div style={{display:"flex",gap:10,flexWrap:"wrap"}}><Link href="/admin/services" className="btn btn-secondary">Manage services <ArrowUpRight size={15}/></Link><Link href="/admin/requests" className="btn btn-primary">Review requests <ArrowUpRight size={15}/></Link></div></div>
  </div>;
}
