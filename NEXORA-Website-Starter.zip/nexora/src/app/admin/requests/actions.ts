"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

const allowed = new Set(["pending","under_review","in_progress","completed","cancelled"]);

export async function updateRequestStatus(formData: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: role } = await supabase.from("user_roles").select("role").eq("user_id",user.id).maybeSingle();
  if (role?.role !== "admin") redirect("/dashboard");
  const id = String(formData.get("id")??"");
  const status = String(formData.get("status")??"");
  if (!id || !allowed.has(status)) throw new Error("Invalid request update.");
  const { error } = await supabase.from("service_requests").update({status,updated_at:new Date().toISOString()}).eq("id",id);
  if (error) throw new Error("Request status could not be updated.");
  revalidatePath("/admin/requests");
  revalidatePath("/dashboard");
}
