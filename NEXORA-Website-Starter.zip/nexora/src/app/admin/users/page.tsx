import { createClient } from "@/lib/supabase/server";

export default async function AdminUsersPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.from("profiles").select("id,full_name,created_at").order("created_at",{ascending:false}).limit(100);
  return <div><div className="eyebrow">People</div><h1 style={{fontSize:32,margin:"10px 0 20px"}}>Users</h1>{error ? <p className="muted">Could not load users. Check the database setup.</p> : <div className="card" style={{padding:18,overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}><thead><tr><th align="left">Name</th><th align="left">User ID</th><th align="left">Joined</th></tr></thead><tbody>{(data??[]).map(u=><tr key={u.id} style={{borderTop:"1px solid #ffffff15"}}><td style={{padding:"13px 8px"}}>{u.full_name||"Unnamed user"}</td><td style={{padding:"13px 8px",color:"#a6a7bb"}}>{u.id.slice(0,8)}…</td><td style={{padding:"13px 8px",color:"#a6a7bb"}}>{new Date(u.created_at).toLocaleDateString()}</td></tr>)}</tbody></table></div>}</div>;
}
