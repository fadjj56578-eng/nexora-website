"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: role } = await supabase.from("user_roles").select("role").eq("user_id",user.id).maybeSingle();
  if (role?.role !== "admin") redirect("/dashboard");
  return supabase;
}

export async function addService(formData: FormData) {
  const supabase = await requireAdmin();
  const title = String(formData.get("title")??"").trim();
  const slug = String(formData.get("slug")??"").trim();
  const description = String(formData.get("description")??"").trim();
  const rawPrice = String(formData.get("price_from")??"").trim();
  const price = rawPrice ? Number(rawPrice) : null;
  if (title.length < 2 || title.length > 100 || !/^[a-z0-9-]+$/.test(slug) || description.length > 1000 || (price !== null && (!Number.isFinite(price)||price<0))) throw new Error("Invalid service details.");
  const { error } = await supabase.from("services").insert({title,slug,description,price_from:price});
  if (error) throw new Error("Service could not be added. Check for a duplicate slug.");
  revalidatePath("/admin/services");
}

export async function toggleService(formData: FormData) {
  const supabase = await requireAdmin();
  const id = String(formData.get("id")??"");
  const active = String(formData.get("active")??"") === "true";
  const { error } = await supabase.from("services").update({active}).eq("id",id);
  if (error) throw new Error("Service status could not be updated.");
  revalidatePath("/admin/services");
}
