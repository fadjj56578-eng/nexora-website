import { createClient } from "@/lib/supabase/server";
import { addService, toggleService } from "./actions";

export default async function AdminServicesPage() {
  const supabase = await createClient();
  const { data: services, error } = await supabase.from("services").select("id,title,slug,active,price_from").order("created_at",{ascending:false});
  return <div><div className="eyebrow">Catalogue</div><h1 style={{fontSize:32,margin:"10px 0 20px"}}>Services</h1>
    <form action={addService} className="card" style={{padding:18,display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10,marginBottom:18}}>
      <input className="field" name="title" required maxLength={100} placeholder="Service title"/>
      <input className="field" name="slug" required pattern="[a-z0-9-]+" placeholder="service-slug"/>
      <input className="field" name="price_from" type="number" min="0" step="0.01" placeholder="Starting price"/>
      <button className="btn btn-primary" style={{border:0,cursor:"pointer"}}>Add service</button>
      <textarea className="field" name="description" required maxLength={1000} placeholder="Short description" rows={2} style={{gridColumn:"1 / -1"}}/>
    </form>
    {error ? <p className="muted">Could not load services. Check the database setup.</p> : <div className="card" style={{padding:18,overflowX:"auto"}}><table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}><thead><tr><th align="left">Service</th><th align="left">Slug</th><th align="left">Starting price</th><th align="left">Status</th><th align="left">Action</th></tr></thead><tbody>{(services??[]).map(s=><tr key={s.id} style={{borderTop:"1px solid #ffffff15"}}><td style={{padding:"13px 8px"}}>{s.title}</td><td style={{padding:"13px 8px",color:"#a6a7bb"}}>{s.slug}</td><td style={{padding:"13px 8px"}}>{s.price_from ?? "Quote"}</td><td style={{padding:"13px 8px"}}>{s.active?"Active":"Inactive"}</td><td style={{padding:"13px 8px"}}><form action={toggleService}><input type="hidden" name="id" value={s.id}/><input type="hidden" name="active" value={String(!s.active)}/><button className="btn btn-secondary" style={{padding:"7px 10px",fontSize:12,cursor:"pointer"}}>{s.active?"Deactivate":"Activate"}</button></form></td></tr>)}</tbody></table></div>}
  </div>;
}
