import { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Layers3, LayoutDashboard, Users, BriefcaseBusiness, ClipboardList, LogOut } from "lucide-react";
import { adminSignOut } from "./signout";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/login");
  const { data: role, error: roleError } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
  if (roleError || role?.role !== "admin") redirect("/dashboard");
  const nav = [{href:"/admin",label:"Overview",Icon:LayoutDashboard},{href:"/admin/users",label:"Users",Icon:Users},{href:"/admin/services",label:"Services",Icon:BriefcaseBusiness},{href:"/admin/requests",label:"Requests",Icon:ClipboardList}];
  return <div className="container" style={{paddingBlock:24,minHeight:"100vh"}}>
    <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:15,flexWrap:"wrap",marginBottom:24}}>
      <Link href="/" style={{display:"flex",alignItems:"center",gap:10,fontWeight:900,letterSpacing:".08em"}}><span style={{display:"grid",placeItems:"center",width:34,height:34,borderRadius:10,background:"linear-gradient(135deg,#8b5cf6,#38bdf8)"}}><Layers3 size={19}/></span>NEXORA / ADMIN</Link>
      <form action={adminSignOut}><button className="btn btn-secondary" style={{fontSize:13,cursor:"pointer"}}><LogOut size={15}/> Sign out</button></form>
    </header>
    <div style={{display:"grid",gridTemplateColumns:"210px minmax(0,1fr)",gap:20}}>
      <aside className="card" style={{padding:12,alignSelf:"start"}}>
        {nav.map(({href,label,Icon})=><Link key={href} href={href} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 10px",borderRadius:10,color:"#d3d3e2",fontSize:13}}><Icon size={17}/>{label}</Link>)}
      </aside>
      <section style={{minWidth:0}}>{children}</section>
    </div>
    <style>{`@media(max-width:700px){.container > div[style*="grid-template-columns: 210px"]{grid-template-columns:1fr!important}}`}</style>
  </div>;
}
