import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ArrowUpRight, FolderKanban, Clock3, CheckCircle2, Layers3, LogOut } from "lucide-react";
import { signOut } from "./signout";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect("/login");
  const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
  if (role?.role === "admin") redirect("/admin");
  const { data: requests } = await supabase.from("service_requests").select("id,title,status,created_at").eq("user_id", user.id).order("created_at",{ascending:false}).limit(20);
  const list = requests ?? [];
  const active = list.filter(r => r.status === "in_progress" || r.status === "under_review").length;
  const completed = list.filter(r => r.status === "completed").length;
  return <main className="container" style={{paddingBlock:28,minHeight:"100vh"}}>
    <header style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:15,flexWrap:"wrap",marginBottom:40}}>
      <Link href="/" style={{display:"flex",alignItems:"center",gap:10,fontWeight:900,letterSpacing:".08em"}}><span style={{display:"grid",placeItems:"center",width:34,height:34,borderRadius:10,background:"linear-gradient(135deg,#8b5cf6,#38bdf8)"}}><Layers3 size={19}/></span>NEXORA / CLIENT PORTAL</Link>
      <form action={signOut}><button className="btn btn-secondary" style={{cursor:"pointer",fontSize:13}}><LogOut size={15}/> Sign out</button></form>
    </header>
    <div className="eyebrow">Your workspace</div><h1 style={{fontSize:"clamp(34px,5vw,52px)",letterSpacing:"-.05em",margin:"10px 0"}}>Welcome back.</h1><p className="muted">Track your service requests and keep your project moving.</p>
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(190px,1fr))",gap:14,marginTop:28}}>
      {[{label:"Total requests",value:list.length,Icon:FolderKanban},{label:"In progress",value:active,Icon:Clock3},{label:"Completed",value:completed,Icon:CheckCircle2}].map(s=><div className="card" key={s.label} style={{padding:22}}><s.Icon size={20} color="#b6a7ff"/><div className="muted" style={{fontSize:13,marginTop:17}}>{s.label}</div><div style={{fontSize:34,fontWeight:800,marginTop:4}}>{s.value}</div></div>)}
    </div>
    <div className="card" style={{padding:22,marginTop:22}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}><h2 style={{fontSize:21,margin:0}}>Your service requests</h2><Link href="/dashboard/new-request" className="btn btn-primary" style={{fontSize:13}}>New request <ArrowUpRight size={15}/></Link></div>
      {list.length ? <div style={{display:"grid",gap:10,marginTop:20}}>{list.map(r=><div key={r.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:15,padding:14,border:"1px solid #ffffff13",borderRadius:12,flexWrap:"wrap"}}><div><strong>{r.title}</strong><div className="muted" style={{fontSize:12,marginTop:5}}>{new Date(r.created_at).toLocaleDateString()}</div></div><span style={{fontSize:12,color:"#c4b5fd",textTransform:"capitalize"}}>{r.status.replaceAll("_"," ")}</span></div>)}</div> : <div style={{textAlign:"center",padding:"38px 12px"}}><FolderKanban size={30} color="#a99aff"/><h3 style={{margin:"12px 0 7px"}}>Your next big idea starts here.</h3><p className="muted" style={{fontSize:13}}>Submit a service request and our team can review your brief.</p></div>}
    </div>
  </main>;
}
