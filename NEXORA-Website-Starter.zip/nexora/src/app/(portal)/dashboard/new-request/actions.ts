"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function createRequest(formData: FormData) {
  const supabase = await createClient();
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) redirect("/login");

  const title = String(formData.get("title") ?? "").trim();
  const brief = String(formData.get("brief") ?? "").trim();
  const serviceValue = String(formData.get("service_id") ?? "").trim();
  const budgetValue = String(formData.get("budget") ?? "").trim();

  if (title.length < 3 || title.length > 120 || brief.length < 10 || brief.length > 5000) {
    throw new Error("Please provide a valid project title and brief.");
  }
  const budget = budgetValue ? Number(budgetValue) : null;
  if (budget !== null && (!Number.isFinite(budget) || budget < 0 || budget > 100000000)) {
    throw new Error("Please enter a valid budget.");
  }

  const payload = {
    user_id: user.id,
    service_id: serviceValue || null,
    title,
    brief,
    budget,
    status: "pending",
  };
  const { error } = await supabase.from("service_requests").insert(payload);
  if (error) throw new Error("Request could not be submitted. Check your database setup and try again.");
  redirect("/dashboard");
}
