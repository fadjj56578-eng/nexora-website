import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createRequest } from "./actions";
import { ArrowLeft } from "lucide-react";

export default async function NewRequestPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: services } = await supabase.from("services").select("id,title").eq("active",true).order("title");
  return <main className="container" style={{paddingBlock:36,minHeight:"100vh",maxWidth:780}}>
    <Link href="/dashboard" style={{display:"inline-flex",gap:8,alignItems:"center",color:"#b8b9cc",fontSize:13,marginBottom:24}}><ArrowLeft size={15}/> Back to dashboard</Link>
    <div className="card" style={{padding:"clamp(22px,5vw,36px)"}}>
      <div className="eyebrow">Tell us what you need</div><h1 style={{fontSize:36,letterSpacing:"-.04em",margin:"12px 0"}}>New service request</h1><p className="muted" style={{lineHeight:1.7}}>Share a few details so the NEXORA team can understand your project.</p>
      <form action={createRequest} style={{display:"grid",gap:18,marginTop:25}}>
        <div><label className="label" htmlFor="service_id">Service</label><select className="field" id="service_id" name="service_id" defaultValue=""><option value="">General inquiry</option>{(services??[]).map(s=><option value={s.id} key={s.id}>{s.title}</option>)}</select></div>
        <div><label className="label" htmlFor="title">Project title</label><input className="field" id="title" name="title" required maxLength={120} placeholder="e.g. New business website"/></div>
        <div><label className="label" htmlFor="brief">Project brief</label><textarea className="field" id="brief" name="brief" required minLength={10} maxLength={5000} rows={6} placeholder="Tell us about your goals, audience, timeline and requirements."/></div>
        <div><label className="label" htmlFor="budget">Estimated budget (optional)</label><input className="field" id="budget" name="budget" type="number" min="0" max="100000000" step="0.01" placeholder="e.g. 50000"/></div>
        <button className="btn btn-primary" style={{border:0,cursor:"pointer"}}>Submit request</button>
      </form>
    </div>
  </main>;
}
