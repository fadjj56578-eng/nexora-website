import dynamic from "next/dynamic";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Code2, Cuboid, Megaphone, Sparkles, MoveUpRight, CheckCircle2 } from "lucide-react";
import Navbar from "@/components/Navbar";

const HeroArt = dynamic(() => import("@/components/HeroArt"), {
  ssr: false,
  loading: () => <div className="glass" style={{height:420,borderRadius:28,display:"grid",placeItems:"center",color:"#aaa"}}>Preparing 3D experience…</div>,
});

const services = [
  {icon:Code2, n:"01", title:"Web Development", desc:"Fast, polished websites and web applications designed around your business goals.", tags:["Business websites","Web apps","E-commerce"]},
  {icon:Cuboid, n:"02", title:"3D Design & Experiences", desc:"Immersive 3D visuals and interactive experiences that make your brand memorable.", tags:["3D visuals","Product scenes","Motion"]},
  {icon:Megaphone, n:"03", title:"Digital Marketing", desc:"Clear digital campaigns that help you reach the right people and grow sustainably.", tags:["Campaign strategy","Social content","SEO foundations"]},
];

export default function Home() {
  return (
    <main>
      <Navbar />
      <section className="container" style={{paddingTop:"clamp(54px,8vw,110px)",paddingBottom:78}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,420px),1fr))",alignItems:"center",gap:24}}>
          <div>
            <div className="eyebrow" style={{display:"flex",alignItems:"center",gap:9}}><Sparkles size={14}/> Digital solutions for ambitious brands</div>
            <h1 style={{fontSize:"clamp(46px,7vw,82px)",lineHeight:1.02,letterSpacing:"-.065em",margin:"22px 0"}}>Build bold.<br/><span className="gradient-text">Design beyond.</span><br/>Grow digitally.</h1>
            <p className="muted" style={{fontSize:17,lineHeight:1.8,maxWidth:530}}>We create powerful digital experiences through web development, 3D design and digital marketing — built to help your business move forward.</p>
            <div style={{display:"flex",gap:12,flexWrap:"wrap",marginTop:28}}>
              <Link href="/signup" className="btn btn-primary">Start a project <ArrowUpRight size={17}/></Link>
              <a href="#services" className="btn btn-secondary">Explore services <ArrowRight size={16}/></a>
            </div>
            <div style={{display:"flex",gap:18,flexWrap:"wrap",marginTop:30,color:"#b4b5c8",fontSize:12}}>
              <span style={{display:"flex",gap:7,alignItems:"center"}}><CheckCircle2 size={15} color="#8bdeef"/> Strategy-led</span>
              <span style={{display:"flex",gap:7,alignItems:"center"}}><CheckCircle2 size={15} color="#8bdeef"/> Design-focused</span>
              <span style={{display:"flex",gap:7,alignItems:"center"}}><CheckCircle2 size={15} color="#8bdeef"/> Built to scale</span>
            </div>
          </div>
          <div className="card" style={{overflow:"hidden",position:"relative",background:"radial-gradient(ellipse at 50% 45%,#28205b 0%,#101226 47%,#090a14 100%)"}}>
            <div style={{position:"absolute",zIndex:1,left:18,top:18}} className="glass">
              <span style={{display:"block",padding:"9px 12px",fontSize:11,color:"#d7d0ff"}}>NEXORA / DIGITAL LAB</span>
            </div>
            <HeroArt/>
            <div style={{position:"absolute",zIndex:1,right:16,bottom:16}} className="glass">
              <span style={{display:"block",padding:"10px 13px",fontSize:11,color:"#d7faff"}}>Ideas into experiences ↗</span>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="container" style={{paddingBlock:70}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"end",gap:20,flexWrap:"wrap",marginBottom:28}}>
          <div><div className="eyebrow">What we do</div><h2 style={{fontSize:"clamp(32px,5vw,48px)",letterSpacing:"-.045em",margin:"12px 0"}}>Digital services, <span className="gradient-text">designed to deliver.</span></h2></div>
          <p className="muted" style={{maxWidth:330,lineHeight:1.7,fontSize:14}}>A focused set of creative and technical services to help your business stand out.</p>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,280px),1fr))",gap:16}}>
          {services.map((s) => { const Icon = s.icon; return <article className="card" key={s.n} style={{padding:24,transition:"transform .2s"}}><div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><span className="glass" style={{width:48,height:48,display:"grid",placeItems:"center",borderRadius:14,color:"#b8a9ff"}}><Icon size={22}/></span><span className="muted" style={{fontSize:12}}>{s.n}</span></div><h3 style={{fontSize:22,margin:"24px 0 10px"}}>{s.title}</h3><p className="muted" style={{lineHeight:1.75,fontSize:14,minHeight:74}}>{s.desc}</p><div style={{display:"flex",flexWrap:"wrap",gap:7,marginTop:17}}>{s.tags.map(t=><span key={t} style={{fontSize:11,color:"#c6c7d9",border:"1px solid #ffffff18",borderRadius:99,padding:"6px 9px"}}>{t}</span>)}</div><Link href="/signup" style={{display:"inline-flex",alignItems:"center",gap:7,marginTop:24,fontSize:13,fontWeight:700,color:"#b8a9ff"}}>Discuss a project <MoveUpRight size={15}/></Link></article>})}
        </div>
      </section>

      <section id="work" className="container" style={{paddingBlock:70}}>
        <div className="card" style={{padding:"clamp(26px,5vw,56px)",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,300px),1fr))",gap:30,alignItems:"center",background:"linear-gradient(125deg,#17172d,#0d1020 65%,#10212b)"}}>
          <div><div className="eyebrow">Built around your goals</div><h2 style={{fontSize:"clamp(30px,4vw,45px)",lineHeight:1.12,letterSpacing:"-.04em",margin:"14px 0"}}>Good work starts with a <span className="gradient-text">clear process.</span></h2><p className="muted" style={{lineHeight:1.8}}>From the first conversation to launch day, we keep the process collaborative, transparent and focused on your goals.</p><Link href="/signup" className="btn btn-primary" style={{marginTop:14}}>Start your brief <ArrowUpRight size={16}/></Link></div>
          <div style={{display:"grid",gap:13}}>{[{n:"01",t:"Discover",d:"Understand your business and audience."},{n:"02",t:"Plan & design",d:"Agree on direction, scope and milestones."},{n:"03",t:"Build & refine",d:"Create, test and improve together."},{n:"04",t:"Launch & grow",d:"Ship confidently and plan next steps."}].map(x=><div key={x.n} style={{display:"flex",gap:15,alignItems:"start",padding:16,border:"1px solid #ffffff12",borderRadius:14,background:"#ffffff05"}}><span style={{color:"#a99aff",fontSize:12,fontWeight:800,paddingTop:3}}>{x.n}</span><div><strong>{x.t}</strong><div className="muted" style={{fontSize:13,marginTop:5}}>{x.d}</div></div></div>)}</div>
        </div>
      </section>

      <section id="about" className="container" style={{paddingBlock:55,textAlign:"center"}}>
        <div className="eyebrow">Your digital partner</div><h2 style={{fontSize:"clamp(32px,5vw,52px)",letterSpacing:"-.05em",margin:"13px auto",maxWidth:760}}>Make your next move <span className="gradient-text">your best one.</span></h2><p className="muted" style={{maxWidth:620,lineHeight:1.8,margin:"0 auto"}}>NEXORA brings strategy, design and technology together to help turn ambitious ideas into useful digital experiences.</p>
      </section>

      <section id="contact" className="container" style={{paddingBlock:"45px 85px"}}>
        <div className="card" style={{textAlign:"center",padding:"clamp(28px,5vw,58px)",background:"radial-gradient(ellipse at top,#30235a,#111222 62%)"}}>
          <div className="eyebrow">Have a project in mind?</div><h2 style={{fontSize:"clamp(30px,5vw,50px)",letterSpacing:"-.05em",margin:"14px 0"}}>Let’s build something <span className="gradient-text">meaningful.</span></h2><p className="muted" style={{lineHeight:1.8}}>Create an account to start a project request and keep track of progress in your client portal.</p><Link href="/signup" className="btn btn-primary" style={{marginTop:18}}>Get started with NEXORA <ArrowUpRight size={16}/></Link>
        </div>
      </section>
      <footer className="container" style={{paddingBlock:22,borderTop:"1px solid #ffffff13",display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap",fontSize:12,color:"#9899ae"}}><span>© {new Date().getFullYear()} NEXORA Digital. All rights reserved.</span><span>Web Development · 3D Design · Digital Marketing</span><span><Link href="/login">Client login</Link></span></footer>
    </main>
  );
}
