"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Layers3, ArrowLeft } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Could not verify your session.");
      const { data: role } = await supabase.from("user_roles").select("role").eq("user_id", user.id).maybeSingle();
      router.push(role?.role === "admin" ? "/admin" : "/dashboard");
      router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Login failed."); }
    finally { setBusy(false); }
  }
  return <main className="container" style={{minHeight:"100vh",display:"grid",placeItems:"center",paddingBlock:35}}>
    <div style={{width:"min(100%,440px)"}}>
      <Link href="/" style={{display:"inline-flex",alignItems:"center",gap:8,color:"#b6b7ca",fontSize:13,marginBottom:24}}><ArrowLeft size={15}/> Back to home</Link>
      <div className="card" style={{padding:30}}>
        <div style={{display:"flex",alignItems:"center",gap:10,fontWeight:900,letterSpacing:".08em"}}><span style={{display:"grid",placeItems:"center",width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,#8b5cf6,#38bdf8)"}}><Layers3 size={19}/></span>NEXORA</div>
        <h1 style={{fontSize:32,margin:"27px 0 8px",letterSpacing:"-.04em"}}>Welcome back</h1><p className="muted" style={{fontSize:14,marginBottom:25}}>Sign in to manage your projects and requests.</p>
        <form onSubmit={submit} style={{display:"grid",gap:16}}>
          <div><label className="label" htmlFor="email">Email address</label><input className="field" id="email" type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></div>
          <div><label className="label" htmlFor="password">Password</label><input className="field" id="password" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password"/></div>
          {error && <p role="alert" style={{color:"#fca5a5",fontSize:13}}>{error}</p>}
          <button className="btn btn-primary" disabled={busy} style={{border:0,cursor:"pointer",opacity:busy ? 0.65 : 1}}>{busy?"Signing in…":"Sign in"}</button>
        </form>
        <p className="muted" style={{fontSize:13,marginTop:22}}>New to NEXORA? <Link href="/signup" style={{color:"#b8a9ff"}}>Create an account</Link></p>
      </div>
    </div>
  </main>;
}
