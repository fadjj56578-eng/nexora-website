"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Layers3, ArrowLeft } from "lucide-react";

export default function SignupPage() {
  const [name,setName] = useState("");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [busy,setBusy] = useState(false);
  const [message,setMessage] = useState("");
  const [error,setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setMessage("");
    if (password.length < 10) { setError("Use a password with at least 10 characters."); setBusy(false); return; }
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signUp({
        email, password,
        options: {
          data: { full_name: name },
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      });
      if (error) throw error;
      setMessage("Account request received. Check your email to verify your address. Your profile and default user role must be provisioned using the SQL migration documented in the setup guide.");
    } catch (err) { setError(err instanceof Error ? err.message : "Signup failed."); }
    finally { setBusy(false); }
  }
  return <main className="container" style={{minHeight:"100vh",display:"grid",placeItems:"center",paddingBlock:35}}>
    <div style={{width:"min(100%,460px)"}}>
      <Link href="/" style={{display:"inline-flex",alignItems:"center",gap:8,color:"#b6b7ca",fontSize:13,marginBottom:24}}><ArrowLeft size={15}/> Back to home</Link>
      <div className="card" style={{padding:30}}>
        <div style={{display:"flex",alignItems:"center",gap:10,fontWeight:900,letterSpacing:".08em"}}><span style={{display:"grid",placeItems:"center",width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,#8b5cf6,#38bdf8)"}}><Layers3 size={19}/></span>NEXORA</div>
        <h1 style={{fontSize:32,margin:"27px 0 8px",letterSpacing:"-.04em"}}>Create your account</h1><p className="muted" style={{fontSize:14,marginBottom:25}}>Start a project and keep your work organised.</p>
        <form onSubmit={submit} style={{display:"grid",gap:16}}>
          <div><label className="label" htmlFor="name">Full name</label><input className="field" id="name" required value={name} onChange={e=>setName(e.target.value)} autoComplete="name" placeholder="Your name"/></div>
          <div><label className="label" htmlFor="email">Email address</label><input className="field" id="email" type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" placeholder="you@example.com"/></div>
          <div><label className="label" htmlFor="password">Password</label><input className="field" id="password" type="password" required minLength={10} value={password} onChange={e=>setPassword(e.target.value)} autoComplete="new-password" placeholder="At least 10 characters"/></div>
          {error && <p role="alert" style={{color:"#fca5a5",fontSize:13}}>{error}</p>}
          {message && <p role="status" style={{color:"#a7f3d0",fontSize:13,lineHeight:1.6}}>{message}</p>}
          <button className="btn btn-primary" disabled={busy} style={{border:0,cursor:"pointer",opacity:busy ? 0.65 : 1}}>{busy?"Creating account…":"Create account"}</button>
        </form>
        <p className="muted" style={{fontSize:13,marginTop:22}}>Already registered? <Link href="/login" style={{color:"#b8a9ff"}}>Sign in</Link></p>
      </div>
    </div>
  </main>;
}
