import Link from "next/link";
import { Layers3, ArrowUpRight } from "lucide-react";

export default function Navbar() {
  return (
    <header className="container" style={{paddingTop:22}}>
      <nav className="glass" style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 16px",borderRadius:16}}>
        <Link href="/" style={{display:"flex",alignItems:"center",gap:10,fontWeight:900,letterSpacing:".08em"}}>
          <span style={{display:"grid",placeItems:"center",width:34,height:34,borderRadius:10,background:"linear-gradient(135deg,#8b5cf6,#38bdf8)"}}><Layers3 size={19}/></span>
          NEXORA
        </Link>
        <div className="hide-mobile" style={{display:"flex",alignItems:"center",gap:26,fontSize:13,color:"#c5c6d6"}}>
          <a href="/#services">Services</a><a href="/#work">Our Work</a><a href="/#about">About</a><a href="/#contact">Contact</a>
        </div>
        <div style={{display:"flex",gap:9,alignItems:"center"}}>
          <Link href="/login" className="btn btn-secondary" style={{padding:"9px 13px",fontSize:13}}>Log in</Link>
          <Link href="/signup" className="btn btn-primary" style={{padding:"9px 13px",fontSize:13}}>Get started <ArrowUpRight size={15}/></Link>
        </div>
      </nav>
    </header>
  );
}
