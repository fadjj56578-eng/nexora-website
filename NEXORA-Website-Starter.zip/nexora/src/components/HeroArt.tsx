"use client";

import { Canvas } from "@react-three/fiber";
import { Float, MeshDistortMaterial, OrbitControls, Sphere, Stars } from "@react-three/drei";

function Scene() {
  return (
    <>
      <ambientLight intensity={1.3} />
      <pointLight position={[3, 3, 4]} intensity={18} color="#8b5cf6" />
      <pointLight position={[-4, -2, 2]} intensity={12} color="#22d3ee" />
      <Stars radius={45} depth={30} count={900} factor={3} saturation={0.4} fade speed={0.6} />
      <Float speed={1.6} rotationIntensity={0.8} floatIntensity={1.2}>
        <Sphere args={[1.15, 96, 96]} scale={[1, 1, 1]}>
          <MeshDistortMaterial color="#7761ef" roughness={0.18} metalness={0.6} distort={0.36} speed={2.2} />
        </Sphere>
      </Float>
      <mesh position={[1.55, -0.65, -0.8]} rotation={[0.5, 0.4, 0.7]}>
        <torusKnotGeometry args={[0.48, 0.11, 120, 18]} />
        <meshStandardMaterial color="#67e8f9" metalness={0.85} roughness={0.2} />
      </mesh>
      <mesh position={[-1.5, 0.9, -1]} rotation={[0.3, 0.4, 0.2]}>
        <icosahedronGeometry args={[0.42, 1]} />
        <meshStandardMaterial color="#c4b5fd" metalness={0.7} roughness={0.22} wireframe />
      </mesh>
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.35} />
    </>
  );
}

export default function HeroArt() {
  return (
    <div aria-label="Animated 3D abstract orb" style={{height:"min(520px, 80vw)",minHeight:300,width:"100%",position:"relative"}}>
      <div style={{position:"absolute",inset:"15%",background:"radial-gradient(circle,#7658f544,transparent 68%)",filter:"blur(25px)"}} />
      <Canvas camera={{position:[0,0,5.4],fov:42}} dpr={[1,1.6]}>
        <Scene />
      </Canvas>
    </div>
  );
}
