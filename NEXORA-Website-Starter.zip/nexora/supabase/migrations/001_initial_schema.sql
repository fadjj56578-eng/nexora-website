-- NEXORA initial schema. Review and test in a non-production project first.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user','admin'))
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = (select auth.uid()) and role = 'admin'
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  description text not null default '',
  price_from numeric(12,2),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.service_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  service_id uuid references public.services(id) on delete set null,
  title text not null,
  brief text not null,
  budget numeric(12,2),
  status text not null default 'pending' check (status in ('pending','under_review','in_progress','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists service_requests_user_id_idx on public.service_requests(user_id);
create index if not exists service_requests_status_idx on public.service_requests(status);

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.services enable row level security;
alter table public.service_requests enable row level security;

drop policy if exists "Read own profile" on public.profiles;
create policy "Read own profile" on public.profiles for select to authenticated using ((select auth.uid()) = id or (select public.is_admin()));
drop policy if exists "Update own profile" on public.profiles;
create policy "Update own profile" on public.profiles for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

drop policy if exists "Read own role" on public.user_roles;
create policy "Read own role" on public.user_roles for select to authenticated using ((select auth.uid()) = user_id or (select public.is_admin()));

drop policy if exists "Read active services" on public.services;
create policy "Read active services" on public.services for select to anon, authenticated using (active or (select public.is_admin()));
drop policy if exists "Admin manages services" on public.services;
create policy "Admin manages services" on public.services for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

drop policy if exists "Read own requests or admin" on public.service_requests;
create policy "Read own requests or admin" on public.service_requests for select to authenticated using ((select auth.uid()) = user_id or (select public.is_admin()));
drop policy if exists "Customers create own requests" on public.service_requests;
create policy "Customers create own requests" on public.service_requests for insert to authenticated with check ((select auth.uid()) = user_id and status = 'pending');
drop policy if exists "Customers cancel own pending requests" on public.service_requests;
create policy "Customers cancel own pending requests" on public.service_requests for update to authenticated using ((select auth.uid()) = user_id and status = 'pending') with check ((select auth.uid()) = user_id and status = 'cancelled');
drop policy if exists "Admin manages requests" on public.service_requests;
create policy "Admin manages requests" on public.service_requests for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));

grant select, insert, update on public.profiles to authenticated;
grant select on public.user_roles to authenticated;
grant select on public.services to anon, authenticated;
grant insert, select, update on public.service_requests to authenticated;
grant insert, update, delete on public.services to authenticated;

-- Provision each new account with a profile and a normal user role.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;

  insert into public.user_roles (user_id, role)
  values (new.id, 'user')
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Seed the three NEXORA services.
insert into public.services (title, slug, description)
values
 ('Web Development', 'web-development', 'Fast, polished websites and web applications designed around your business goals.'),
 ('3D Design & Experiences', '3d-design', 'Immersive 3D visuals and interactive experiences that make your brand memorable.'),
 ('Digital Marketing', 'digital-marketing', 'Digital campaigns and strategy to help your business reach the right audience.')
on conflict (slug) do nothing;
